# Project Reflection: AI Customer Support Agent

## Design Decision
To optimize latency and architecture complexity, I decided to implement the Bedrock Knowledge Base search and Code Interpreter calculations directly within the Strands `Agent` initialization via local Python functions decorated with `@tool`, rather than provisioning separate Lambda functions behind API Gateway. This architectural choice simplified tool routing through the MCP Gateway, reserving the Gateway strictly for sensitive, state-modifying backend API operations (`order-tracker` and `refund-processor`). This hybrid approach prevents unnecessary network hops and reduces overall execution time for stateless, read-only customer inquiries.

## Challenge Encountered & Diagnostic Resolution
During development, undocumented API updates and schema shifts in the Strands SDK caused runtime failures in the `MemoryHook` event handlers. Specifically, `HookRegistry.register()` was deprecated in favor of `add_callback()`, and internal message representations migrated to dictionary structures with nested blocks. 

To diagnose this problem, I first inspected the runtime object hierarchy using Python's `inspect` module and logged `event.agent.messages` to trace message structures across multiple turns. I discovered that tool invocations produced intermediate `user` messages containing `toolResult` blocks without a `"text"` property. This caused `AttributeError` exceptions and prevented customer interaction turns from persisting to Bedrock AgentCore Memory. 

To resolve the issue, I redesigned `save_support_interaction` and `retrieve_customer_context` to recursively filter message content, safely isolating plain-text user inputs from `toolResult` and `toolUse` blocks. I also updated namespace lookup to support both `namespaceTemplates` and legacy `namespaces`. 

I verified the resolution by running a two-session test with customer ID `CUST-123`: Session A stored a personal preference, followed by a 45-second indexing pause, and Session B confirmed that the agent accurately recalled the stored context across session boundaries without errors.

## Production Consideration
Before deploying this assistant in a high-traffic production environment, security and cost optimizations must be addressed. First, static environment variables must be replaced by hosting the agent natively on the Bedrock AgentCore Runtime with an IAM execution role adhering to the principle of least privilege. Second, to manage API expenses during extended conversations, I would enable prompt caching and conversation summarization to minimize token usage. Finally, structured output validation with Pydantic models should be added to validate tool schemas and prevent hallucinations before customer presentation.
